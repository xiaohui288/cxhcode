#ifndef _TOOLS_H
#define _TOOLS_H

#include <ros/ros.h>
#include "prometheus_msgs/Message.h"

namespace Global_Planning
{
    extern ros::Publisher message_pub;
}
#endif