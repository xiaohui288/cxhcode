#include "tools.h"

namespace Global_Planning
{
    ros::Publisher message_pub;
}